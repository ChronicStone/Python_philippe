# pylint: disable=missing-docstring

# Here is what you need to do:
#   1. Write some code below
#   2. Save to disk with Ctrl + S (Windows) or Cmd + S (Mac)
#   3. Run the code
print("hello world!")