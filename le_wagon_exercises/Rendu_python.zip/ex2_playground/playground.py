# TODO: it's a playground, let's write some code (no unit tests to run here)

radius =5
perimeter = 3.141592653589793*(radius*2)
area=3.141592653589793*(radius*radius)
perimeter = round(perimeter,1)
print(perimeter)
area = round(area,1)
print(area)
print(f'The radius is set to {radius}')
print(f'Perimeter of the circle is {perimeter}')
print(f'Area of the disk is {area}')